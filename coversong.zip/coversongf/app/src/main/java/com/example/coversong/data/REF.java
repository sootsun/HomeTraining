package com.example.coversong.data;

public enum REF {
    LIST, USER
}
